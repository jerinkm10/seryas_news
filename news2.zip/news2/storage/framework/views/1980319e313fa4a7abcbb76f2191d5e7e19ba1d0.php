<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="MediaCenter, Template, eCommerce">
<meta name="robots" content="all">
<title>Marazzo premium HTML5 & CSS3 Template</title>

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="<?php echo e(url('/assets/css/bootstrap.min.css')); ?>">

<!-- Customizable CSS -->
<link rel="stylesheet" href="<?php echo e(url('/assets/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/blue.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/owl.transitions.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/rateit.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/assets/css/bootstrap-select.min.css')); ?>">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="<?php echo e(url('/assets/css/font-awesome.css')); ?>">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
</head>
<body class="cnt-home">
<!-- ============================================== HEADER ============================================== -->

<!-- ============================================== HEADER : END ============================================== -->
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Blog</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
	<div class="container">
		<div class="row">
        <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>" id="csrf_token">
			<div class="blog-page">
				<div class="col-xs-12 col-sm-9 col-md-9 rht-col" id="feeds">
                    <?php if(!empty($data)){  ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="blog-post  wow fadeInUp">
                                <a href="blog-details.html"><img class="img-responsive" src="<?php echo e($value->urlToImage); ?>" alt=""></a>
                                <h1><a href="blog-details.html"><?php echo e($value->title); ?></a></h1>
                                <span class="author"><?php echo e($value->author); ?></span>
    
                                <span class="date-time"><?php echo e($value->publishedAt); ?></span>
                                <p><?php echo e($value->description); ?></p>
                                <a href="#" class="btn btn-upper btn-primary read-more">read more</a>
                            </div>
                           
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php } ?>


<div class="clearfix blog-pagination filters-container  wow fadeInUp" style="padding:0px; background:none; box-shadow:none; margin-top:15px; border:none">
						
	<div class="text-right">
         <div class="pagination-container">
	<ul class="list-inline list-unstyled">
		<li class="prev"><a href="#"><i class="fa fa-angle-left"></i></a></li>
		<li><a href="#">1</a></li>	
		<li class="active"><a href="#">2</a></li>	
		<li><a href="#">3</a></li>	
		<li><a href="#">4</a></li>	
		<li class="next"><a href="#"><i class="fa fa-angle-right"></i></a></li>
	</ul><!-- /.list-inline -->
</div><!-- /.pagination-container -->    </div><!-- /.text-right -->

</div><!-- /.filters-container -->				</div>
				<div class="col-xs-12 col-sm-3 col-md-3 sidebar">
                
                
                
					<div class="sidebar-module-container">
						<div class="search-area outer-bottom-small">
    <form>
        <div class="control-group">
            <input placeholder="Type to search" class="search-field" id="search">
            <a href="#" class="search-button" id="searches"></a>   
        </div>
        <div class="control-group">
        
    </form>
</div>		

<div class="home-banner outer-top-n outer-bottom-xs">
</div>
	<!-- ==============================================CATEGORY============================================== -->
	<!-- ============================================== CATEGORY : END ============================================== -->
    <div class="sidebar-widget outer-bottom-xs wow fadeInUp">
        <label for="cars">Choose a Order:</label>

        <select name="order" id="order">
                <option value="10">10</option>
                <option value="100">100</option>
        </select>
	</div>
</div>
						<!-- ============================================== PRODUCT TAGS ============================================== -->
<!-- ============================================== PRODUCT TAGS : END ============================================== -->					</div>
				</div>
			</div>
		</div>
		<!-- ============================================== BRANDS CAROUSEL ============================================== -->
<div id="brands-carousel" class="logo-slider wow fadeInUp">

		
	
</div><!-- /.logo-slider -->
<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->	</div>
</div>
<!-- ============================================================= FOOTER ============================================================= -->

        <!-- ============================================== INFO BOXES ============================================== -->
       
        <!-- /.info-boxes --> 
        <!-- ============================================== INFO BOXES : END ============================================== --> 

<!-- ============================================================= FOOTER ============================================================= -->
<!-- ============================================================= FOOTER : END============================================================= --> 

<!-- For demo purposes – can be removed on production --> 

<!-- For demo purposes – can be removed on production : End --> 

<!-- JavaScripts placed at the end of the document so the pages load faster --> 
<script src="<?php echo e(url('/assets/js/jquery-1.11.1.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/bootstrap-hover-dropdown.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/owl.carousel.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/echo.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/jquery.easing-1.3.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/bootstrap-slider.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/jquery.rateit.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(url('/assets/js/lightbox.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/bootstrap-select.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/wow.min.js')); ?>"></script> 
<script src="<?php echo e(url('/assets/js/scripts.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
 <script>  
 $(document).ready(function(){  

    $("#order").change(function(ev){
        var id  = $("#order").val();
        var search  = $("#search").val();
        // alert(id);
			$.ajax({
			  type: "POST",
			  headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') },
			  url: '/search',
			  data: { _token: $('#csrf_token').val(), 
				search: search,
				id: id
			  },
			  success: function(aData) {
			   
			   if(aData.success == 1){
				
				console.log(aData);
				var body ="";
				$.each(aData.data, function(k, value) {
					body +='<div class="blog-post  wow fadeInUp"><a href="blog-details.html"><img class="img-responsive" src="'+value.urlToImage+'" alt=""></a><h1><a href="blog-details.html">'+value.title+'</a></h1><span class="author">'+value.author+'</span><span class="date-time">'+value.publishedAt+'</span><p>'+value.description+'</p><a href="#" class="btn btn-upper btn-primary read-more">read more</a></div>';
				});
				//alert(body);
                $("#feeds").html(body);
				swal("success!", " Successfully  Rated!", "success");
			   }else if(aData.success == 0){
				   $(this).show();
				swal("ERROR!", "Server Error ", "success");
			   }
				},
				
			});
    });
    $("#searches").click(function(ev){
        var id  = $("#order").val();
        var search  = $("#search").val();
        // alert(id);
			$.ajax({
			  type: "POST",
			  headers: { 'X-CSRF-Token' : $('meta[name=_token]').attr('content') },
			  url: '/search',
			  data: { _token: $('#csrf_token').val(), 
				search: search,
				id: id
			  },
			  success: function(aData) {
			   
			   if(aData.success == 1){
				console.log(aData);
			
				var body ="";
				$.each(aData.data, function(k, value) {
					body +='<div class="blog-post  wow fadeInUp"><a href="blog-details.html"><img class="img-responsive" src="'+value.urlToImage+'" alt=""></a><h1><a href="blog-details.html">'+value.title+'</a></h1><span class="author">'+value.author+'</span><span class="date-time">'+value.publishedAt+'</span><p>'+value.description+'</p><a href="#" class="btn btn-upper btn-primary read-more">read more</a></div>';
				});
				//alert(body);
                $("#feeds").html(body);
				swal("success!", " Successfully  Rated!", "success");
			   }else if(aData.success == 0){
				   $(this).show();
				swal("ERROR!", "Server Error ", "success");
			   }
				},
				
			});
    });

});
 </script>  

</html><?php /**PATH D:\xampp\htdocs\news2\resources\views/welcome.blade.php ENDPATH**/ ?>